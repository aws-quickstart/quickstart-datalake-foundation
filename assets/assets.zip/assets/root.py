import os

PROJECT_DIR = os.path.dirname(__file__)